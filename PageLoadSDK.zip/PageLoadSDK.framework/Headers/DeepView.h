//
//  DeepView.h
//  PageLoadSDK
//
//  Created by Bill Snook  on 2/13/19.
//  Copyright © 2019 Impact Tech Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

// Yes when debugging so we do not make the pageload call all the time
#define BLOCK_CALL_TO_PAGELOAD       NO

#define TEST_VERSION                @"v8"


@interface DeepView : NSObject

@property NSString *security_authorization;
@property Boolean useSecurity;


- (void)challenge: (NSString *)username secret: (NSString *)password;
- (void)pageLoad: (int)campaignID;

@end

NS_ASSUME_NONNULL_END
